(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customBwChartjs', function() {
    return {
      controllerAs: 'ctrl',
      controller: /**
 * The controller is a JavaScript function that augments the AngularJS scope and exposes functions that can be used in the custom widget template
 * 
 * Custom widget properties defined on the right can be used as variables in a controller with $scope.properties
 * To use AngularJS standard services, you must declare them in the main function arguments.
 * 
 * You can leave the controller empty if you do not need it.
 */
function ($scope) {
    console.log(angular.version);
    /*
    $scope.type = 'chart-line';
    if ($scope.properties.type == 'Line') {
       $scope.type = 'chart-line';
    } else if ($scope.properties.type == 'Bar') {
        $scope.type = 'chart-bar';
    }
    console.log('chart type ' + $scope.type);
    
    if (!$scope.properties.options) {
        console.log('default chart options');
        $scope.properties.options = { legend: { display: true } };
    }
    */
    $scope.options = { legend: { display: true } };
    $scope.labels = ['2006', '2007', '2008', '2009', '2010', '2011', '2012'];
    $scope.series = ['Series A', 'Series B'];
    $scope.data = [
      [65, 59, 80, 81, 56, 55, 40],
      [28, 48, 40, 19, 86, 27, 90]
    ];    
},
      template: '<!-- The custom widget template is defined here\n   - You can use standard HTML tags and AngularJS built-in directives, scope and interpolation system\n   - Custom widget properties defined on the right can be used as variables in a templates with properties.newProperty\n   - Functions exposed in the controller can be used with ctrl.newFunction()\n   - You can use the \'environment\' property injected in the scope when inside the Editor whiteboard. It allows to define a mockup\n     of the Custom Widget to be displayed in the whiteboard only. By default the widget is represented by an auto-generated icon\n     and its name (See the <span> below).\n-->\n \n<span ng-if="environment"><identicon name="{{environment.component.id}}" size="30" background-color="[255,255,255, 0]" foreground-color="[51,51,51]"></identicon> {{environment.component.name}}</span>\n<span ng-if="environment">{{properties.chartId}} {{properties.type}}</span>\n\n<div>\n<canvas id="{{properties.chartId}}" ng-if="properties.type == \'Line\'" class="chart chart-line" chart-data="data" chart-labels="labels" chart-series="series" chart-options="options"></canvas>\n<canvas id="{{properties.chartId}}" ng-if="properties.type == \'Bar\'" class="chart chart-bar" chart-data="data" chart-labels="labels" chart-series="series" chart-options="options"></canvas>\n</div>\n\n'
    };
  });
